public abstract class Aves extends Mascotas {
    protected String pico;
    protected boolean vuela;
    
    public abstract String volar();
}